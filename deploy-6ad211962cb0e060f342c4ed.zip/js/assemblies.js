(function () {
  'use strict';

  // 2 Assemblies Gallery Images in Exact Order
  const images = [
    {
      src: 'https://www.orbigreentech.com/assets/708fd822-e66e-4e96-bd9d-f2b6cc359ffc-BCO8sTe1.png',
      title: 'Assemblies Sample 01',
      alt: 'Sub-assemblies and integrated mechanical assemblies sample 01'
    },
    {
      src: 'https://www.orbigreentech.com/assets/3207aac8-7ffa-4340-b3c7-6359cd66542a-0Gh0ZTe8.png',
      title: 'Assemblies Sample 02',
      alt: 'Sub-assemblies and integrated mechanical assemblies sample 02'
    }
  ];

  let currentIndex = 0;
  const totalCount = images.length;

  // DOM Elements
  const mainImg = document.getElementById('mainProductImg');
  const counterVal = document.getElementById('galleryCounterVal');
  const captionTitle = document.getElementById('galleryCaptionTitle');
  const prevBtn = document.getElementById('galleryPrevBtn');
  const nextBtn = document.getElementById('galleryNextBtn');
  const thumbs = document.querySelectorAll('.thumb-btn');
  const thumbsContainer = document.getElementById('thumbnailsStrip');
  const galleryStage = document.getElementById('mainGalleryStage');

  function formatIndex(idx) {
    const num = idx + 1;
    return (num < 10 ? '0' + num : String(num)) + '/' + (totalCount < 10 ? '0' + totalCount : String(totalCount));
  }

  function updateGallery(newIndex, withTransition = true) {
    if (newIndex < 0) {
      newIndex = totalCount - 1;
    } else if (newIndex >= totalCount) {
      newIndex = 0;
    }

    currentIndex = newIndex;
    const item = images[currentIndex];

    // Update Counter (format 01/02)
    if (counterVal) {
      counterVal.textContent = formatIndex(currentIndex);
    }

    // Update Caption
    if (captionTitle) {
      captionTitle.textContent = item.title;
    }

    // Update Main Image
    if (mainImg) {
      if (withTransition) {
        mainImg.classList.add('fading');
        setTimeout(() => {
          mainImg.src = item.src;
          mainImg.alt = item.alt;
          mainImg.classList.remove('fading');
        }, 120);
      } else {
        mainImg.src = item.src;
        mainImg.alt = item.alt;
      }
    }

    // Update Thumbnails Active State
    thumbs.forEach((thumb, idx) => {
      const isActive = idx === currentIndex;
      thumb.classList.toggle('active', isActive);
      thumb.setAttribute('aria-selected', String(isActive));
      thumb.setAttribute('tabindex', isActive ? '0' : '-1');
    });

    // Scroll active thumbnail smoothly into view
    const activeThumb = thumbs[currentIndex];
    if (activeThumb && thumbsContainer) {
      const containerLeft = thumbsContainer.getBoundingClientRect().left;
      const thumbLeft = activeThumb.getBoundingClientRect().left;
      const offset = thumbLeft - containerLeft - (thumbsContainer.clientWidth / 2) + (activeThumb.clientWidth / 2);
      thumbsContainer.scrollBy({ left: offset, behavior: 'smooth' });
    }
  }

  // Navigation button event listeners
  if (prevBtn) {
    prevBtn.addEventListener('click', () => {
      updateGallery(currentIndex - 1);
    });
  }

  if (nextBtn) {
    nextBtn.addEventListener('click', () => {
      updateGallery(currentIndex + 1);
    });
  }

  // Thumbnail click
  thumbs.forEach((thumb) => {
    thumb.addEventListener('click', () => {
      const idx = parseInt(thumb.getAttribute('data-index') || '0', 10);
      updateGallery(idx);
    });
  });

  // Keyboard navigation
  document.addEventListener('keydown', (e) => {
    const activeEl = document.activeElement;
    const isInput = activeEl && (activeEl.tagName === 'INPUT' || activeEl.tagName === 'TEXTAREA' || activeEl.isContentEditable);
    if (isInput) return;

    if (e.key === 'ArrowLeft') {
      e.preventDefault();
      updateGallery(currentIndex - 1);
    } else if (e.key === 'ArrowRight') {
      e.preventDefault();
      updateGallery(currentIndex + 1);
    }
  });

  // Touch Swipe on mobile gallery stage
  if (galleryStage) {
    let touchStartX = 0;
    let touchEndX = 0;

    galleryStage.addEventListener('touchstart', (e) => {
      touchStartX = e.changedTouches[0].screenX;
    }, { passive: true });

    galleryStage.addEventListener('touchend', (e) => {
      touchEndX = e.changedTouches[0].screenX;
      const diffX = touchEndX - touchStartX;
      if (Math.abs(diffX) > 40) {
        if (diffX > 0) {
          updateGallery(currentIndex - 1);
        } else {
          updateGallery(currentIndex + 1);
        }
      }
    }, { passive: true });
  }

  // Resilient image loading
  document.querySelectorAll('img').forEach((img) => {
    img.addEventListener('error', function () {
      this.style.opacity = '0.9';
      this.src = 'https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&w=800&q=80';
    });
  });

  // Header scroll state
  const header = document.getElementById('header');
  const onScroll = () => {
    if (header) {
      header.classList.toggle('scrolled', window.scrollY > 40);
    }
  };
  onScroll();
  window.addEventListener('scroll', onScroll, { passive: true });

  // Mobile navigation toggle
  const btn = document.getElementById('menuBtn');
  if (btn) {
    btn.addEventListener('click', () => {
      const open = document.body.classList.toggle('menu-open');
      btn.setAttribute('aria-expanded', String(open));
      document.body.style.overflow = open ? 'hidden' : '';
      if (header) header.classList.add('scrolled');
    });
  }

  document.querySelectorAll('#mobileNav a').forEach((a) => {
    a.addEventListener('click', () => {
      document.body.classList.remove('menu-open');
      if (btn) btn.setAttribute('aria-expanded', 'false');
      document.body.style.overflow = '';
      onScroll();
    });
  });

  // Reveal on scroll
  const reveals = document.querySelectorAll('.rv');
  if (reveals.length) {
    if ('IntersectionObserver' in window) {
      document.documentElement.classList.add('js');
      const io = new IntersectionObserver(
        (entries) => {
          entries.forEach((e) => {
            if (e.isIntersecting) {
              e.target.classList.add('in');
              io.unobserve(e.target);
            }
          });
        },
        { threshold: 0.05, rootMargin: '0px 0px 40px 0px' }
      );
      reveals.forEach((el) => {
        const rect = el.getBoundingClientRect();
        if (rect.top < window.innerHeight && rect.bottom > 0) {
          el.classList.add('in');
        } else {
          io.observe(el);
        }
      });
      setTimeout(() => {
        reveals.forEach((el) => el.classList.add('in'));
      }, 1200);
    } else {
      reveals.forEach((el) => el.classList.add('in'));
    }
  }

  // Dynamic copyright year
  const yr = document.getElementById('yr');
  if (yr) {
    yr.textContent = String(new Date().getFullYear());
  }

  // Initial gallery setup
  updateGallery(0, false);
})();
