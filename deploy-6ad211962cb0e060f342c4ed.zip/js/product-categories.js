(function () {
  // Header scroll state
  const header = document.getElementById('header');
  const onScroll = () => {
    if (header) {
      header.classList.toggle('scrolled', window.scrollY > 40);
    }
  };
  onScroll();
  window.addEventListener('scroll', onScroll, { passive: true });

  // Mobile menu
  const btn = document.getElementById('menuBtn');
  if (btn) {
    btn.addEventListener('click', () => {
      const open = document.body.classList.toggle('menu-open');
      btn.setAttribute('aria-expanded', String(open));
      document.body.style.overflow = open ? 'hidden' : '';
      if (header) header.classList.add('scrolled');
    });
  }

  document.querySelectorAll('#mobileNav a').forEach((a) => {
    a.addEventListener('click', () => {
      document.body.classList.remove('menu-open');
      if (btn) btn.setAttribute('aria-expanded', 'false');
      document.body.style.overflow = '';
      onScroll();
    });
  });

  // Reveal on scroll (fail-safe with immediate viewport check)
  const reveals = document.querySelectorAll('.rv');
  if (reveals.length) {
    if ('IntersectionObserver' in window) {
      document.documentElement.classList.add('js');
      const io = new IntersectionObserver(
        (entries) => {
          entries.forEach((e) => {
            if (e.isIntersecting) {
              e.target.classList.add('in');
              io.unobserve(e.target);
            }
          });
        },
        { threshold: 0.05, rootMargin: '0px 0px 40px 0px' }
      );
      reveals.forEach((el) => {
        const rect = el.getBoundingClientRect();
        if (rect.top < window.innerHeight && rect.bottom > 0) {
          el.classList.add('in');
        } else {
          io.observe(el);
        }
      });
      setTimeout(() => {
        reveals.forEach((el) => el.classList.add('in'));
      }, 1200);
    } else {
      reveals.forEach((el) => el.classList.add('in'));
    }
  }

  // Resilient image loading: attach fallback on load error
  document.querySelectorAll('.product-img-wrap img').forEach((img) => {
    img.addEventListener('error', function () {
      // In case an external image URL is blocked in an offline or hermetic environment,
      // replace with high-quality fallback and retain professional aesthetic
      this.style.opacity = '0.85';
      this.src = 'https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&w=800&q=80';
    });
  });

  // Contact form validation & submission
  const form = document.getElementById('categoryInquiryForm');
  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      let ok = true;
      form.querySelectorAll('[required]').forEach((field) => {
        const wrap = field.closest('.field');
        const input = field;
        let valid = input.value.trim() !== '';
        if (input.type === 'email') {
          valid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(input.value.trim());
        }
        if (wrap) wrap.classList.toggle('err', !valid);
        if (!valid && ok) {
          input.focus();
          ok = false;
        }
      });
      if (ok) {
        form.classList.add('sent');
        form.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    });

    form.querySelectorAll('input, select, textarea').forEach((f) => {
      f.addEventListener('input', () => {
        const wrap = f.closest('.field');
        if (wrap) wrap.classList.remove('err');
      });
    });
  }

  // Dynamic copyright year
  const yr = document.getElementById('yr');
  if (yr) {
    yr.textContent = String(new Date().getFullYear());
  }
})();
