(function () {
  'use strict';

  // 9 Pressure Vessels Gallery Images in Exact Order
  const images = [
    {
      src: 'https://www.orbigreentech.com/assets/0bd569a3-f5e5-43ec-93ee-a9c788dbe07b-BPstnlgD.png',
      title: 'Pressure Vessel Sample 01',
      alt: 'Engineered industrial pressure vessel and storage tank sample 01'
    },
    {
      src: 'https://www.orbigreentech.com/assets/0f42c2ac-117a-4a1e-b416-025fc11ba980-BaP6nlRp.png',
      title: 'Pressure Vessel Sample 02',
      alt: 'Engineered industrial pressure vessel and storage tank sample 02'
    },
    {
      src: 'https://www.orbigreentech.com/assets/1-CPsaVzyP.png',
      title: 'Pressure Vessel Sample 03',
      alt: 'Engineered industrial pressure vessel and storage tank sample 03'
    },
    {
      src: 'https://www.orbigreentech.com/assets/2-Brs6LUlq.png',
      title: 'Pressure Vessel Sample 04',
      alt: 'Engineered industrial pressure vessel and storage tank sample 04'
    },
    {
      src: 'https://www.orbigreentech.com/assets/c411cd3b-3a1c-44dc-9064-97d07d618a1d-BkR06MMS.png',
      title: 'Pressure Vessel Sample 05',
      alt: 'Engineered industrial pressure vessel and storage tank sample 05'
    },
    {
      src: 'https://www.orbigreentech.com/assets/WhatsApp%20Image%202026-08-11%20at%206.53.17%20PM%20(7)-BTuXdrfk.jpeg',
      title: 'Pressure Vessel Sample 06',
      alt: 'Engineered industrial pressure vessel and storage tank sample 06'
    },
    {
      src: 'https://www.orbigreentech.com/assets/WhatsApp%20Image%202026-08-11%20at%206.53.17%20PM%20(8)-DQ2TWCq9.jpeg',
      title: 'Pressure Vessel Sample 07',
      alt: 'Engineered industrial pressure vessel and storage tank sample 07'
    },
    {
      src: 'https://www.orbigreentech.com/assets/WhatsApp%20Image%202026-08-11%20at%206.53.17%20PM%20(9)-D9sLeiyq.jpeg',
      title: 'Pressure Vessel Sample 08',
      alt: 'Engineered industrial pressure vessel and storage tank sample 08'
    },
    {
      src: 'https://www.orbigreentech.com/assets/WhatsApp%20Image%202026-08-11%20at%206.53.17%20PM%20(10)-qOTwUveY.jpeg',
      title: 'Pressure Vessel Sample 09',
      alt: 'Engineered industrial pressure vessel and storage tank sample 09'
    }
  ];

  let currentIndex = 0;
  const totalCount = images.length;

  // DOM Elements
  const mainImg = document.getElementById('mainProductImg');
  const counterVal = document.getElementById('galleryCounterVal');
  const captionTitle = document.getElementById('galleryCaptionTitle');
  const prevBtn = document.getElementById('galleryPrevBtn');
  const nextBtn = document.getElementById('galleryNextBtn');
  const thumbs = document.querySelectorAll('.thumb-btn');
  const thumbsContainer = document.getElementById('thumbnailsStrip');
  const galleryStage = document.getElementById('mainGalleryStage');

  function formatIndex(idx) {
    const num = idx + 1;
    return (num < 10 ? '0' + num : String(num)) + '/' + (totalCount < 10 ? '0' + totalCount : String(totalCount));
  }

  function updateGallery(newIndex, withTransition = true) {
    if (newIndex < 0) {
      newIndex = totalCount - 1;
    } else if (newIndex >= totalCount) {
      newIndex = 0;
    }

    currentIndex = newIndex;
    const item = images[currentIndex];

    // Update Counter (format 01/09)
    if (counterVal) {
      counterVal.textContent = formatIndex(currentIndex);
    }

    // Update Caption
    if (captionTitle) {
      captionTitle.textContent = item.title;
    }

    // Update Main Image with smooth transition
    if (mainImg) {
      if (withTransition) {
        mainImg.classList.add('fading');
        setTimeout(() => {
          mainImg.src = item.src;
          mainImg.alt = item.alt;
          mainImg.classList.remove('fading');
        }, 120);
      } else {
        mainImg.src = item.src;
        mainImg.alt = item.alt;
      }
    }

    // Update Thumbnails Active State
    thumbs.forEach((thumb, idx) => {
      const isActive = idx === currentIndex;
      thumb.classList.toggle('active', isActive);
      thumb.setAttribute('aria-selected', String(isActive));
      thumb.setAttribute('tabindex', isActive ? '0' : '-1');
    });

    // Scroll active thumbnail smoothly into view
    const activeThumb = thumbs[currentIndex];
    if (activeThumb && thumbsContainer) {
      const containerLeft = thumbsContainer.getBoundingClientRect().left;
      const thumbLeft = activeThumb.getBoundingClientRect().left;
      const offset = thumbLeft - containerLeft - (thumbsContainer.clientWidth / 2) + (activeThumb.clientWidth / 2);
      thumbsContainer.scrollBy({ left: offset, behavior: 'smooth' });
    }
  }

  // Navigation button event listeners
  if (prevBtn) {
    prevBtn.addEventListener('click', () => {
      updateGallery(currentIndex - 1);
    });
  }

  if (nextBtn) {
    nextBtn.addEventListener('click', () => {
      updateGallery(currentIndex + 1);
    });
  }

  // Thumbnail click event listeners
  thumbs.forEach((thumb) => {
    thumb.addEventListener('click', () => {
      const idx = parseInt(thumb.getAttribute('data-index') || '0', 10);
      updateGallery(idx);
    });
  });

  // Keyboard navigation
  document.addEventListener('keydown', (e) => {
    const activeEl = document.activeElement;
    const isInput = activeEl && (activeEl.tagName === 'INPUT' || activeEl.tagName === 'TEXTAREA' || activeEl.isContentEditable);
    if (isInput) return;

    if (e.key === 'ArrowLeft') {
      e.preventDefault();
      updateGallery(currentIndex - 1);
    } else if (e.key === 'ArrowRight') {
      e.preventDefault();
      updateGallery(currentIndex + 1);
    }
  });

  // Touch Swipe on mobile gallery stage
  if (galleryStage) {
    let touchStartX = 0;
    let touchEndX = 0;

    galleryStage.addEventListener('touchstart', (e) => {
      touchStartX = e.changedTouches[0].screenX;
    }, { passive: true });

    galleryStage.addEventListener('touchend', (e) => {
      touchEndX = e.changedTouches[0].screenX;
      const diffX = touchEndX - touchStartX;
      if (Math.abs(diffX) > 40) {
        if (diffX > 0) {
          updateGallery(currentIndex - 1);
        } else {
          updateGallery(currentIndex + 1);
        }
      }
    }, { passive: true });
  }

  // Resilient image loading: attach fallback on load error
  document.querySelectorAll('img').forEach((img) => {
    img.addEventListener('error', function () {
      this.style.opacity = '0.9';
      this.src = 'https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&w=800&q=80';
    });
  });

  // Header scroll state
  const header = document.getElementById('header');
  const onScroll = () => {
    if (header) {
      header.classList.toggle('scrolled', window.scrollY > 40);
    }
  };
  onScroll();
  window.addEventListener('scroll', onScroll, { passive: true });

  // Mobile navigation toggle
  const btn = document.getElementById('menuBtn');
  if (btn) {
    btn.addEventListener('click', () => {
      const open = document.body.classList.toggle('menu-open');
      btn.setAttribute('aria-expanded', String(open));
      document.body.style.overflow = open ? 'hidden' : '';
      if (header) header.classList.add('scrolled');
    });
  }

  document.querySelectorAll('#mobileNav a').forEach((a) => {
    a.addEventListener('click', () => {
      document.body.classList.remove('menu-open');
      if (btn) btn.setAttribute('aria-expanded', 'false');
      document.body.style.overflow = '';
      onScroll();
    });
  });

  // Reveal on scroll (fail-safe with immediate viewport check)
  const reveals = document.querySelectorAll('.rv');
  if (reveals.length) {
    if ('IntersectionObserver' in window) {
      document.documentElement.classList.add('js');
      const io = new IntersectionObserver(
        (entries) => {
          entries.forEach((e) => {
            if (e.isIntersecting) {
              e.target.classList.add('in');
              io.unobserve(e.target);
            }
          });
        },
        { threshold: 0.05, rootMargin: '0px 0px 40px 0px' }
      );
      reveals.forEach((el) => {
        const rect = el.getBoundingClientRect();
        if (rect.top < window.innerHeight && rect.bottom > 0) {
          el.classList.add('in');
        } else {
          io.observe(el);
        }
      });
      setTimeout(() => {
        reveals.forEach((el) => el.classList.add('in'));
      }, 1200);
    } else {
      reveals.forEach((el) => el.classList.add('in'));
    }
  }

  // Dynamic copyright year
  const yr = document.getElementById('yr');
  if (yr) {
    yr.textContent = String(new Date().getFullYear());
  }

  // Initial gallery setup: display first image (01/09)
  updateGallery(0, false);
})();
