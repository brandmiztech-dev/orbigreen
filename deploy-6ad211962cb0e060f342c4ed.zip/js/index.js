(function () {
  // Header scroll state
  const header = document.getElementById('header');
  const onScroll = () => {
    if (header) {
      header.classList.toggle('scrolled', window.scrollY > 40);
    }
  };
  onScroll();
  window.addEventListener('scroll', onScroll, { passive: true });

  // Mobile menu
  const btn = document.getElementById('menuBtn');
  if (btn) {
    btn.addEventListener('click', () => {
      const open = document.body.classList.toggle('menu-open');
      btn.setAttribute('aria-expanded', String(open));
      document.body.style.overflow = open ? 'hidden' : '';
      if (header) header.classList.add('scrolled');
    });
  }

  document.querySelectorAll('#mobileNav a').forEach((a) => {
    a.addEventListener('click', () => {
      document.body.classList.remove('menu-open');
      if (btn) btn.setAttribute('aria-expanded', 'false');
      document.body.style.overflow = '';
      onScroll();
    });
  });

  // Video toggle
  const v = document.getElementById('heroVideo');
  const vt = document.getElementById('videoToggle');
  const vl = document.getElementById('vLabel');
  const vi = document.getElementById('vIcon');

  if (v && vt && vl && vi) {
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const setIcon = (playing) => {
      vi.innerHTML = playing
        ? '<rect x="2" y="1" width="3" height="10"/><rect x="7" y="1" width="3" height="10"/>'
        : '<path d="M2 1l9 5-9 5z"/>';
      vl.textContent = playing ? 'Pause' : 'Play';
      vt.setAttribute('aria-label', playing ? 'Pause background video' : 'Play background video');
    };

    if (reduce) {
      v.pause();
      v.removeAttribute('autoplay');
      setIcon(false);
    }

    vt.addEventListener('click', () => {
      if (v.paused) {
        v.play();
        setIcon(true);
      } else {
        v.pause();
        setIcon(false);
      }
    });
  }

  // Ticker duplicate for seamless loop
  const track = document.getElementById('tickerTrack');
  if (track) {
    track.innerHTML += track.innerHTML;
    track.querySelectorAll('span').forEach((s, i) => {
      if (i >= track.children.length / 2) {
        s.setAttribute('aria-hidden', 'true');
      }
    });
  }

  // Solutions accordion + image swap
  const items = [...document.querySelectorAll('.sol-item')];
  const imgs = [...document.querySelectorAll('.sol-visual img')];
  const num = document.getElementById('solNum');
  const nm = document.getElementById('solName');

  items.forEach((it, idx) => {
    const trigger = it.querySelector('.sol-trigger');
    if (trigger) {
      trigger.addEventListener('click', () => {
        items.forEach((o) => {
          o.classList.remove('active');
          const t = o.querySelector('.sol-trigger');
          if (t) t.setAttribute('aria-expanded', 'false');
        });
        it.classList.add('active');
        trigger.setAttribute('aria-expanded', 'true');
        imgs.forEach((im, i) => im.classList.toggle('on', i === idx));
        if (num) num.textContent = String(idx + 1).padStart(2, '0');
        const h3 = it.querySelector('h3');
        if (nm && h3) nm.textContent = h3.textContent;
      });
    }
  });

  // Reveal on scroll (fail-safe with immediate viewport check)
  const reveals = document.querySelectorAll('.rv');
  if (reveals.length) {
    if ('IntersectionObserver' in window) {
      document.documentElement.classList.add('js');
      const io = new IntersectionObserver(
        (entries) => {
          entries.forEach((e) => {
            if (e.isIntersecting) {
              e.target.classList.add('in');
              io.unobserve(e.target);
            }
          });
        },
        { threshold: 0.05, rootMargin: '0px 0px 40px 0px' }
      );
      reveals.forEach((el) => {
        const rect = el.getBoundingClientRect();
        if (rect.top < window.innerHeight && rect.bottom > 0) {
          el.classList.add('in');
        } else {
          io.observe(el);
        }
      });
      setTimeout(() => {
        reveals.forEach((el) => el.classList.add('in'));
      }, 1200);
    } else {
      reveals.forEach((el) => el.classList.add('in'));
    }
  }

  // File name
  const file = document.getElementById('file');
  const fn = document.getElementById('fileName');
  if (file && fn) {
    file.addEventListener('change', () => {
      fn.textContent = file.files && file.files.length ? file.files[0].name : 'Attach drawings (PDF, STEP, DWG)';
    });
  }

  // Form validation
  const form = document.getElementById('rfqForm');
  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      let ok = true;
      form.querySelectorAll('[required]').forEach((field) => {
        const wrap = field.closest('.field');
        const input = field;
        let valid = input.value.trim() !== '';
        if (input.type === 'email') {
          valid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(input.value.trim());
        }
        if (wrap) wrap.classList.toggle('err', !valid);
        if (!valid && ok) {
          input.focus();
          ok = false;
        }
      });
      if (ok) {
        form.classList.add('sent');
        form.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    });

    form.querySelectorAll('input, select, textarea').forEach((f) => {
      f.addEventListener('input', () => {
        const wrap = f.closest('.field');
        if (wrap) wrap.classList.remove('err');
      });
    });
  }

  // Current year
  const yr = document.getElementById('yr');
  if (yr) {
    yr.textContent = String(new Date().getFullYear());
  }
})();
